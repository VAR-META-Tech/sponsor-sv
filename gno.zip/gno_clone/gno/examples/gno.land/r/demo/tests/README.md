Modules here are only useful for file realm tests.
They can be safely ignored for other purposes.
