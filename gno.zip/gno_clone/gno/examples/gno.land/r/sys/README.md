#`r/sys/*`

This folder contains contracts designed for chain use. All content should be
minimal, future-proof, and gas-efficient.

