# r/x/manfred_outfmt

PoC of output formatting options.
