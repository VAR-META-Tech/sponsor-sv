Various upgrade pattern explorations.
