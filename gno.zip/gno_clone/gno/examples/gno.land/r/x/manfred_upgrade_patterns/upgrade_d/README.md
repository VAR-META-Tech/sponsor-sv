# Lazy Migration Example

This example demonstrates lazy migrations from v1 to v2 of a data structure in Gno.

## Notes

Uses AVL trees, but storage can vary since public Get functions are used.

v1 can be made pausable and readonly during migration.
