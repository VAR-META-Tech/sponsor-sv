# Fixed size 256-bit math library

This is a library specialized at replacing the `big.Int` library for math based on 256-bit types.

original repository: [uint256](<https://github.com/holiman/uint256/tree/master>)
