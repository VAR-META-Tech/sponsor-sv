# GRC-1155 Spec: Multi Token Standard

GRC1155 is a specification for managing multiple tokens based on Gnoland. The name and design is based on Ethereum's ERC1155 standard.

## See also:

[ERC-1155 Spec][erc-1155]

[erc-1155]: https://eips.ethereum.org/EIPS/eip-1155