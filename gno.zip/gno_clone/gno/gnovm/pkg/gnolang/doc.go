// SPDX-License-Identifier: GNO License Version 1.0
package gnolang
