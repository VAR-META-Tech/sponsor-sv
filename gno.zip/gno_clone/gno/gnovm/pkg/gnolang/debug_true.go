//go:build debug

package gnolang

const debug debugging = true
