The subdirectories here core standard packages provided for Gno smart contracts.
They are also made available for files tests.

The files in this directory are adapters for native Go.
