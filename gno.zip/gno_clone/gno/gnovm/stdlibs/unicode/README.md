Directly copied from go1.17.5. BSD license.
TestCalibrate() commented out for import reasons.

