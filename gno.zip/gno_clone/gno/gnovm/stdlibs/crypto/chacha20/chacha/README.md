From https://github.com/aead/chacha20/tree/master/chacha
