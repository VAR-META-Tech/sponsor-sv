Just the interfaces ported from https://pkg.go.dev/crypto/cipher@go1.17.5
