GOAL: improve standard errors.
Survey feedback for Unwrap() before supporting it.
Compare to implementation in pkgs/errors.
