package testing

func X_unixNano() int64 {
	// only implemented in testing stdlibs
	return 0
}
