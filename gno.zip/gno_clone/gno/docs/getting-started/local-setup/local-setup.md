---
id: local-setup
---

# Local setup
This section will show you how to set up a local environment for Gno development.
It includes instructions for installation, setting up a Gno.land keypair, 
browsing Gno source code, and more. 