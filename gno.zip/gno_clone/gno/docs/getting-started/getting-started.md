---
id: getting-started
---

# Getting started

Welcome to the **Getting Started** section for Gno. This section outlines how to
get started with Gno by using the Gno Playground, as well as how to set up a 
local development environment, get funds, deploy packages, etc.