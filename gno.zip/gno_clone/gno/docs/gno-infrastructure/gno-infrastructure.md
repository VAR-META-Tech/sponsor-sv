---
id: gno-infrastructure
---

# Gno Infrastructure

Welcome to the **Gno Infrastructure** section. This section is meant for users
wanting to learn how to run their own Gno node, set up their own faucet, run
an indexer service, and more.