 * [eris_agreement.pdf](./eris_agreement.pdf) - This 2015 agreement was
   necessary to publish Tendermint under Apache2.0. Since then Eris Industries
   has become Monax.  Ethan Buchman at the time was an external contributor
   from Eris Industries to the Tendermint project. Due to intermixing of
   contributions without a clear license agreement, our relative contributions
   had to be split out to convince Eris to allow us to publish everything under
   Apache2.0.
