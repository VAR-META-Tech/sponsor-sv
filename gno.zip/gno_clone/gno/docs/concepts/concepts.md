---
id: concepts
---

# Concepts

Welcome to the **Concepts** section for Gno. This section outlines the most important
concepts related to Gno & Gno.land.