This folder contains configuration of various development dependencies.
