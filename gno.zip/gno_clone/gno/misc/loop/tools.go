//go:build tools

package tools

import (
	_ "github.com/gnolang/gno/gno.land/cmd/gnoland"
	_ "github.com/gnolang/tx-archive/cmd"
)
