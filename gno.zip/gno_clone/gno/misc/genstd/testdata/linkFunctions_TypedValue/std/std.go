package std

import (
	gno "github.com/gnolang/gno/gnovm/pkg/gnolang"
)

func TVParam(p gno.TypedValue) {
}

func TVResult() gno.TypedValue {
	return gno.TypedValue{}
}

func TVFull(m *gno.Machine, v gno.TypedValue) gno.TypedValue {
	return gno.TypedValue{}
}
