package std

func Y() {}
