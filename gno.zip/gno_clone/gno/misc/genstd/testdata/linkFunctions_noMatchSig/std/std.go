package std

import (
	gno "github.com/gnolang/gno/gnovm/pkg/gnolang"
)

func X(m *gno.Machine, n string) {
}
