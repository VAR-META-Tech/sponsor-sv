# Autocounterd

## What is it?

`autocounterd` is a simple binary that increments a simple counter every x seconds to analyse and test a network.

## How to use

Start it with:

``` sh
$ docker compose up -d
```
