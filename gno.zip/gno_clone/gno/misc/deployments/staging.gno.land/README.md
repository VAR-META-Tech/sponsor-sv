# staging.gno.land

an environment that is automatically redeployed:
* after each new commit/PR merge on master,
* once a day.

the deployments are automatic and may fail.

the chain state (data) is regularly reset.
