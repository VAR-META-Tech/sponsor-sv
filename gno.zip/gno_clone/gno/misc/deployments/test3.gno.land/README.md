# test3.gno.land

second official testnet.
