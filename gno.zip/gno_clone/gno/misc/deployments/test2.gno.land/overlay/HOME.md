Welcome to test2.gno.land.

 * [Install `gnokey`](https://github.com/gnolang/gno/)
 * [Acquire testnet tokens](/faucet)

Explore new packages.

 * [/p/avl](/p/avl)
 * [/r/boards](/r/boards)
 * [/r/nft](/r/nft)
 * [/r/users](/r/users)
 * [/r/banktest](/r/banktest)
 * [/p/grc/grc20](/p/grc/grc20)
 * [/p/grc/grc721](/p/grc/grc721)
 * [/r/foo20](/r/foo20)

This is a testnet. \
Package names are not guaranteed to be available for production.\
To be guaranteed a package and realm name, [register](/r/users).

Also, join our [Discord](https://discord.gg/tF2X8M6cVj).
