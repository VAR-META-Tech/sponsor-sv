# test2.gno.land

second official testnet.
