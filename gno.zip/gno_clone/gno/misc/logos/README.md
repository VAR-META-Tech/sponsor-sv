## Logos Browser

[Logos](/logos) is a Gno object browser.  The modern browser as well as the
modern javascript ecosystem is from a security point of view, completely fucked.
The entire paradigm of continuously updating browsers with incrementally added
features is a security nightmare.

The Logos browser is based on a new model that is vastly simpler than HTML.
The purpose of Logos is to become a fully expressive web API and implementation
standard that does most of what HTML and the World Wide Web originally intended
to do, but without becoming more complex than necessary.
