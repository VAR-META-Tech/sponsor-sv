# docker-integration

This folder contains tests that runs integration tests inside Docker, using the CLIs.

We encourage to keep the tests simple and focusing on cross-component testing.
