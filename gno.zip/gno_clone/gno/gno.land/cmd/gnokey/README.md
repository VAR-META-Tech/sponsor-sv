# gnokey

`gnokey` is a tool for managing https://gno.land accounts and interact with instances.

## Install `gnokey`

    $> git clone git@github.com:gnolang/gno.git
    $> cd ./gno
    $> make install_gnokey

Also, see the [quickstart guide](https://github.com/gnolang/gno/blob/master/examples/gno.land/r/demo/boards/README.md).
