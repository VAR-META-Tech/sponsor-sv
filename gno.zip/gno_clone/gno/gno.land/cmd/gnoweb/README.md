# gnoweb

The gno.land web interface.

Live demo: https://test3.gno.land/

## Install `gnoweb`

Install and run a local [`gnoland`](../gnoland) instance first.

    $> git clone git@github.com:gnolang/gno.git
    $> cd ./gno/gno.land
    $> make install.gnoweb
