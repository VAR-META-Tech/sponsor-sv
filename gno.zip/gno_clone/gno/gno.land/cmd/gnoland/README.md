# `gnoland`

## Install `gnoland`

    $> git clone git@github.com:gnolang/gno.git
    $> cd ./gno/gno.land
    $> make install.gnoland

## Run `gnoland` full node

    $> gnoland start

Afterward, you can interact with [`gnokey`](../gnokey) or launch a [`gnoweb`](../gnoweb) interface.
