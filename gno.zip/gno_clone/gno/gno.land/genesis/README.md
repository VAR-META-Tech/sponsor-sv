# Gno.land genesis

**WIP: see https://github.com/gnolang/independence-day**
